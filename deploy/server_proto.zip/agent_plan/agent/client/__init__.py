"""Client-side agent package."""
