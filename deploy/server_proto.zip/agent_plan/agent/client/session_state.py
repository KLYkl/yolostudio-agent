from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(slots=True)
class DatasetContext:
    dataset_root: str = ""
    img_dir: str = ""
    label_dir: str = ""
    data_yaml: str = ""
    last_scan: dict[str, Any] = field(default_factory=dict)
    last_validate: dict[str, Any] = field(default_factory=dict)
    last_readiness: dict[str, Any] = field(default_factory=dict)
    last_split: dict[str, Any] = field(default_factory=dict)
    last_health_check: dict[str, Any] = field(default_factory=dict)
    last_duplicate_check: dict[str, Any] = field(default_factory=dict)
    last_extract_preview: dict[str, Any] = field(default_factory=dict)
    last_extract_result: dict[str, Any] = field(default_factory=dict)
    last_video_scan: dict[str, Any] = field(default_factory=dict)
    last_frame_extract: dict[str, Any] = field(default_factory=dict)



@dataclass(slots=True)
class PredictionContext:
    source_path: str = ""
    model: str = ""
    output_dir: str = ""
    report_path: str = ""
    last_result: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class KnowledgeContext:
    last_retrieval: dict[str, Any] = field(default_factory=dict)
    last_analysis: dict[str, Any] = field(default_factory=dict)
    last_recommendation: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class TrainingContext:
    running: bool = False
    model: str = ""
    data_yaml: str = ""
    device: str = ""
    training_environment: str = ""
    project: str = ""
    run_name: str = ""
    batch: int | None = None
    imgsz: int | None = None
    fraction: float | None = None
    classes: list[int] = field(default_factory=list)
    single_cls: bool | None = None
    optimizer: str = ""
    freeze: int | None = None
    resume: bool | None = None
    lr0: float | None = None
    patience: int | None = None
    workers: int | None = None
    amp: bool | None = None
    pid: int | None = None
    log_file: str = ""
    started_at: float | None = None
    last_status: dict[str, Any] = field(default_factory=dict)
    last_summary: dict[str, Any] = field(default_factory=dict)
    training_run_summary: dict[str, Any] = field(default_factory=dict)
    last_start_result: dict[str, Any] = field(default_factory=dict)
    last_environment_probe: dict[str, Any] = field(default_factory=dict)
    last_preflight: dict[str, Any] = field(default_factory=dict)
    recent_runs: list[dict[str, Any]] = field(default_factory=list)
    last_run_inspection: dict[str, Any] = field(default_factory=dict)
    training_plan_draft: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class PendingConfirmation:
    thread_id: str = ""
    tool_name: str = ""
    tool_args: dict[str, Any] = field(default_factory=dict)
    created_at: str = ""


@dataclass(slots=True)
class UserPreferences:
    default_model: str = ""
    default_epochs: int | None = None
    language: str = "zh-CN"


@dataclass(slots=True)
class SessionState:
    session_id: str
    created_at: str = field(default_factory=utc_now)
    updated_at: str = field(default_factory=utc_now)
    active_dataset: DatasetContext = field(default_factory=DatasetContext)
    active_training: TrainingContext = field(default_factory=TrainingContext)
    active_prediction: PredictionContext = field(default_factory=PredictionContext)
    active_knowledge: KnowledgeContext = field(default_factory=KnowledgeContext)
    pending_confirmation: PendingConfirmation = field(default_factory=PendingConfirmation)
    preferences: UserPreferences = field(default_factory=UserPreferences)

    def touch(self) -> None:
        self.updated_at = utc_now()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'SessionState':
        return cls(
            session_id=data['session_id'],
            created_at=data.get('created_at', utc_now()),
            updated_at=data.get('updated_at', utc_now()),
            active_dataset=DatasetContext(**data.get('active_dataset', {})),
            active_training=TrainingContext(**data.get('active_training', {})),
            active_prediction=PredictionContext(**data.get('active_prediction', {})),
            active_knowledge=KnowledgeContext(**data.get('active_knowledge', {})),
            pending_confirmation=PendingConfirmation(**data.get('pending_confirmation', {})),
            preferences=UserPreferences(**data.get('preferences', {})),
        )
