"""YoloStudio agent prototype package."""
